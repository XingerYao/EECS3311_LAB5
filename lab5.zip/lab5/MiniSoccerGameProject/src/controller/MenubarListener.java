package controller;

import model.SoccerGame;
import view.GamePanel;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// TODO: Auto-generated Javadoc
/**
 * The listener interface for receiving menubar events.
 * The class that is interested in processing a menubar
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addMenubarListener<code> method. When
 * the menubar event occurs, that object's appropriate
 * method is invoked.
 *
 * @see MenubarEvent
 */
public class MenubarListener implements ActionListener {

	/** The game panel. */
	private final GamePanel gamePanel;

	/**
	 * Instantiates a new menubar listener.
	 *
	 * @param panel
	 */
	public MenubarListener(GamePanel panel) {
		gamePanel = panel;
	}


	/**
	 * Action performed.
	 *
	 * @param e 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		SoccerGame soccerGame = gamePanel.getGame();
		switch (e.getActionCommand()) {
			case "NEW":
				gamePanel.setupSoccerGame();
				break;
			case "EXIT":
				System.exit(0);
				break;
			case "PAUSE":
				if (!soccerGame.isPaused() && !soccerGame.isOver()) {
					soccerGame.setPaused(true);
				} else if (soccerGame.isPaused()) {
					System.out.println("game is already on pause!");
				} else if (soccerGame.isOver()) {
					System.out.println("game is over, please start a new game.");
				}
				break;
			case "RESUME":
				if (soccerGame.isPaused() && !soccerGame.isOver()) {
					soccerGame.setPaused(false);
				} else if (!soccerGame.isPaused()) {
					System.out.println("game is already running!");
				} else if (soccerGame.isOver()) {
					System.out.println("game is over, please start a new game.");
				}
				break;
			default:
				throw new RuntimeException("Invalid action command " + e.getActionCommand());
		}
	}
}
