package test;

import static org.junit.Assert.*;

import org.junit.Test;

import model.players.PlayerStatistics;

// TODO: Auto-generated Javadoc
/**
 * The Class PlayerStatisticsTest.
 */
public class PlayerStatisticsTest {

	/**
	 * Test.
	 */
	@Test
	public void test() {
		PlayerStatistics	playerStatistics = new PlayerStatistics();
		assertEquals(0,playerStatistics.getStatistics().intValue());
	}

}
